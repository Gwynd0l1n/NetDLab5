﻿Option Strict On
Imports System.IO
Public Class frmTextEditor
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
        '' I wanted to do something else instead of this but a certain someone caught me and wouldnt let me :C
    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        If ofdChildOne.ShowDialog() = DialogResult.OK Then
            Try
                ''Apparently the reader is rather dim, who knew ? Now, do I mean the one reading this or the variable? ;)
                Dim Reader As New StreamReader(ofdChildOne.FileName)
                txtEditor.Text = Reader.ReadToEnd
                Reader.Close()
                '' Catches any exceptions. 
            Catch ex As Exception
                Throw New ApplicationException(ex.ToString())
            End Try
        End If
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click
        ''Opens SaveFileDialog
        Dim sfd As New SaveFileDialog()
        ''Filters for txt and All files.
        sfd.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        ''Index assignment
        sfd.FilterIndex = 1
        sfd.RestoreDirectory = True
        If sfd.ShowDialog() = DialogResult.OK Then
            Dim FileName As String = sfd.FileName
            Dim sw As New System.IO.StreamWriter(FileName, False)
            ''Writes the document to the text editor
            sw.WriteLine(txtEditor.Text)
            sw.Close()
        End If
    End Sub

    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click
        ''Closes the document via wiping the text. 
        txtEditor.Text = ""
    End Sub

    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click
        sfdChildTwo.Filter = "TXT Files (*.txt*)|*.txt*"
        If sfdChildTwo.ShowDialog() = DialogResult.OK Then
            ''Saves the text to a new file. 
            My.Computer.FileSystem.WriteAllText(sfdChildTwo.FileName, txtEditor.Text, False)
        End If
    End Sub

    Private Sub NewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewToolStripMenuItem.Click
        ''Starts a new document via wiping the text. 
        txtEditor.Text = ""
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        MsgBox("Author: A not shit ADC named Kyle Edwards" + vbCrLf + "Class: NetD 2202" + vbCrLf + "Lab: 5", MsgBoxStyle.OkOnly, "About")
    End Sub

    Private Sub PasteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PasteToolStripMenuItem.Click
        ''Replaces targeted text with clipboard content.  
        txtEditor.SelectedText = Clipboard.GetText
    End Sub

    Private Sub CutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CutToolStripMenuItem.Click
        ''First pulls the selected text, then wipes the selected text from the existing document. 
        Clipboard.SetText(txtEditor.SelectedText)
        txtEditor.SelectedText = ""
    End Sub

    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        ''Copies dat shit. 
        Clipboard.SetText(txtEditor.SelectedText)
    End Sub
End Class
